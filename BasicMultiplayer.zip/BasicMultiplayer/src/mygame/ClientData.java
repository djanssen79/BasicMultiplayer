package mygame;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.network.serializing.Serializable;

/**
 * A class that stores the position and the rotation of a player. Even if not a
 * message, this class must be made serializable as it is used in a
 * Message-class
 *
 * @author danieljanssen
 */
@Serializable
public class ClientData {

    private Vector3f position;
    private Quaternion rotation;

    public ClientData() {
        // no-argument constructor necessary
    }

    public ClientData(Vector3f pPosition, Quaternion pRotation) {
        this.position = pPosition;
        this.rotation = pRotation;
    }

    /**
     * @return the position
     */
    public Vector3f getPosition() {
        return position;
    }

    /**
     * @return the rotation
     */
    public Quaternion getRotation() {
        return rotation;
    }

    /**
     * @param pPosition the position to set
     */
    public void setPosition(Vector3f pPosition) {
        this.position = pPosition;
    }

    /**
     * @param pRotation the rotation to set
     */
    public void setRotation(Quaternion pRotation) {
        this.rotation = pRotation;
    }
}
