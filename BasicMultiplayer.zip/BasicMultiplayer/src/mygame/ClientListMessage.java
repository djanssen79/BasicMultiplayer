package mygame;

import com.jme3.network.AbstractMessage;
import com.jme3.network.serializing.Serializable;
import java.util.HashMap;

/**
 * this message contains a hashmap with player ID and the corresponding
 * ClientData-Object
 *
 * @author danieljanssen
 */
@Serializable
public class ClientListMessage extends AbstractMessage {

    private HashMap<Integer, ClientData> clientList;

    public ClientListMessage() {
    }    // empty constructor

    public ClientListMessage(HashMap<Integer, ClientData> clientList) {
        this.clientList = clientList;
    }

    public HashMap<Integer, ClientData> getClientList() {
        return clientList;
    }

}
