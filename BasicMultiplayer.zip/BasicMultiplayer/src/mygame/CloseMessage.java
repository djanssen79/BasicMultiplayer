package mygame;

import com.jme3.network.AbstractMessage;
import com.jme3.network.serializing.Serializable;

/**
 * a CloseMessage is used to handle a closed client connection and only stores
 * the id of a player
 *
 * @author danieljanssen
 */
@Serializable
public class CloseMessage extends AbstractMessage {

    private int id;

    public CloseMessage() {
    }    // empty constructor

    public CloseMessage(int pId) {
        this.id = pId;
    } // custom constructor

    public int getID() {
        return id;
    }

}
