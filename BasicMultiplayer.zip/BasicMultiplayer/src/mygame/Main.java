package mygame;

import com.jme3.system.JmeContext;
import org.lwjgl.opengl.Display;

public class Main {

    private static String serverIP = "localhost";

    /**
     * Change as you like, only a dumb hardcoded choice here between client and
     * server For testing purpose change the static boolean here or provide an
     * argument when starting the app via shell, e.g.: 
     * java -jar Main.jar 192.168.1.107 (for client to connect to the given IP) 
     * java -jar Main.jar (for server)
     *
     * @param args provide nothing for client and an argument for server
     */
    public static void main(String args[]) {
        // Start a client with the given IP in args[0]
        if (args.length > 0) {
            serverIP = args[0];
            try {
                MainClient app = new MainClient(serverIP);                
                //Display.setLocation(650, 490); // ONLY FOR TESTING
                //app.setPauseOnLostFocus(false); // ONLY FOR TESTING                
                app.start();
            } catch (Exception e) {
                System.out.println("Client could not be started!");
            }
        } 
        // Start a server
        else {
            try {
                MainServer app = new MainServer();
                app.start(JmeContext.Type.Headless);
            } catch (Exception e) {
                System.out.println("Server could not be started or is already running!");
            }
        }
    }
}
