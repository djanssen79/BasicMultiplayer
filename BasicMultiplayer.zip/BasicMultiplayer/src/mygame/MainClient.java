package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.network.Client;
import com.jme3.network.ClientStateListener;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.network.Network;
import com.jme3.network.serializing.Serializer;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.jme3.scene.shape.Sphere;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

public class MainClient extends SimpleApplication implements ActionListener, ClientStateListener, MessageListener<Client> {

    private BulletAppState bulletAppState;
    private CharacterControl player;
    private final Vector3f walkDirection = new Vector3f();
    private boolean left = false, right = false, up = false, down = false;
    private final Vector3f camDir = new Vector3f();
    private final Vector3f camLeft = new Vector3f();
    private final float worldWidth = 64f;
    private Node playersNode;
    private Client myClient;
    private final String serverIP;
    private final int serverPort = 1234;
    private HashMap<Integer, ClientData> players;
    private HashMap<Integer, Spatial> spatials;

    public MainClient(String pServerIP) {
        super();
        serverIP = pServerIP;
    }

    /**
     * Floor we can walk on and a kind of sky
     */
    private void initScene() {
        Box boxMesh = new Box(worldWidth, 1.0f, worldWidth);
        Geometry floorGeom = new Geometry("Box", boxMesh);
        Material boxMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        boxMat.setColor("Color", ColorRGBA.Brown);
        floorGeom.setMaterial(boxMat);
        floorGeom.setLocalTranslation(0, -0.1f, 0);
        floorGeom.addControl(new RigidBodyControl(0));
        bulletAppState.getPhysicsSpace().add(floorGeom);
        rootNode.attachChild(floorGeom);
        viewPort.setBackgroundColor(ColorRGBA.Blue);
    }

    /**
     * A placeholder for a spatial that represents a player, teammate or enemy
     *
     * @param pID player ID
     * @return the spatial of the player
     */
    private Spatial generateSphere(int pID) {
        Sphere sMesh = new Sphere(32, 32, 1.0f);
        Geometry sGeo = new Geometry("" + pID, sMesh);
        Material sMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        sMat.setColor("Color", ColorRGBA.LightGray);
        sGeo.setMaterial(sMat);
        return sGeo;
    }

    @Override
    public void simpleInitApp() {
        players = new HashMap<>();
        spatials = new HashMap<>();
        playersNode = new Node();
        rootNode.attachChild(playersNode);
        // Network connection first
        try {
            myClient = Network.connectToServer(serverIP, serverPort);
            Serializer.registerClass(PositionRotationMessage.class);
            Serializer.registerClass(ClientData.class);
            Serializer.registerClass(ClientListMessage.class);
            Serializer.registerClass(CloseMessage.class);
            myClient.addMessageListener(this);
            myClient.addClientStateListener(this);
            myClient.start();
        } catch (IOException ex) {
            System.out.println("Connection to server not possible");
        }

        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);
        flyCam.setMoveSpeed(100);
        setUpKeys();
        initScene();

        // Player
        CapsuleCollisionShape shape = new CapsuleCollisionShape(1.5f, 1.5f, 1);
        player = new CharacterControl(shape, 0.05f);
        player.setJumpSpeed(20);
        player.setFallSpeed(30);
        bulletAppState.getPhysicsSpace().add(player);
        player.setGravity(new Vector3f(0, -50f, 0));
        player.setPhysicsLocation(new Vector3f((float) (Math.random() * (worldWidth - 2)), 10, (float) (Math.random() * (worldWidth - 2))));
    }

    private void setUpKeys() {
        inputManager.addMapping("Left", new KeyTrigger(KeyInput.KEY_A));
        inputManager.addMapping("Right", new KeyTrigger(KeyInput.KEY_D));
        inputManager.addMapping("Up", new KeyTrigger(KeyInput.KEY_W));
        inputManager.addMapping("Down", new KeyTrigger(KeyInput.KEY_S));
        inputManager.addMapping("Jump", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addListener(this, "Left");
        inputManager.addListener(this, "Right");
        inputManager.addListener(this, "Up");
        inputManager.addListener(this, "Down");
        inputManager.addListener(this, "Jump");
    }

    @Override
    public void onAction(String binding, boolean isPressed, float tpf) {
        switch (binding) {
            case "Left":
                left = isPressed;
                break;
            case "Right":
                right = isPressed;
                break;
            case "Up":
                up = isPressed;
                break;
            case "Down":
                down = isPressed;
                break;
            case "Jump":
                player.jump(new Vector3f(0, 11f, 0));
                break;
            default:
                break;
        }
    }

    @Override
    public void simpleUpdate(float tpf) {
        camDir.set(cam.getDirection()).multLocal(0.3f); //0.6
        camLeft.set(cam.getLeft()).multLocal(0.2f); //0.4
        walkDirection.set(0, 0, 0);
        if (left) {
            walkDirection.addLocal(camLeft);
        }
        if (right) {
            walkDirection.addLocal(camLeft.negate());
        }
        if (up) {
            walkDirection.addLocal(camDir);
        }
        if (down) {
            walkDirection.addLocal(camDir.negate());
        }
        player.setWalkDirection(walkDirection);
        cam.setLocation(player.getPhysicsLocation());
    }

    @Override
    public void clientConnected(Client c) {

    }

    @Override
    public void clientDisconnected(Client c, DisconnectInfo info) {

    }

    @Override
    public void messageReceived(Client source, Message pMessage) {

        // this client receives a message with the positions and rotations of all clients in the game
        if (pMessage instanceof ClientListMessage) {

            ClientListMessage clm = (ClientListMessage) pMessage;
            // update the players-HashMap with a list of ClientData objects
            players.putAll((HashMap<Integer, ClientData>) clm.getClientList());

            // each entry contains a ClientData object
            for (Map.Entry playerEntry : players.entrySet()) {
                // fetch the data from the entry
                final int playerEntryID = (int) playerEntry.getKey();
                ClientData tmp = (ClientData) playerEntry.getValue();
                final Vector3f playerEntryVec = tmp.getPosition();
                final Quaternion playerEntryRot = tmp.getRotation();

                // do updates only if not the own ID
                if (playerEntryID != myClient.getId()) {
                    // if a new player is in the list - add it to the spatials
                    if (!spatials.containsKey(playerEntryID)) {
                        spatials.put((Integer) playerEntryID, generateSphere(playerEntryID));
                        // add new spatial to the scene (via Callable)
                        enqueue(new Callable() {
                            @Override
                            public Object call() throws Exception {
                                playersNode.attachChild(spatials.get(playerEntryID));
                                return null;
                            }
                        });
                    }
                    // now update all other spatials in the scene (via Callable)
                    enqueue(new Callable() {
                        @Override
                        public Object call() throws Exception {
                            spatials.get(playerEntryID).setLocalTranslation(playerEntryVec.add(new Vector3f(0, -1, 0)));
                            spatials.get(playerEntryID).setLocalRotation(playerEntryRot);
                            return null;
                        }
                    });
                }
            }
        } // a player with the id pID has disconnected - remove from players and spatials
        else if (pMessage instanceof CloseMessage) {
            CloseMessage cm = (CloseMessage) pMessage;
            final int pID = cm.getID();
            players.remove(pID);
            // detach spatial from the scene (via Callable)
            enqueue(new Callable() {
                @Override
                public Object call() throws Exception {
                    playersNode.detachChild(spatials.get(pID));
                    return null;
                }
            });
        }
        // now send the client's position itself to the server
        myClient.send(new PositionRotationMessage(cam.getLocation(), cam.getRotation()));
    }

    @Override
    public void destroy() {
        if (myClient != null && myClient.isConnected()) {
            myClient.close();
        }
    }
}
