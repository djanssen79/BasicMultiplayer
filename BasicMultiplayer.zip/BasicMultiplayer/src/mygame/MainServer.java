package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.network.ConnectionListener;
import com.jme3.network.HostedConnection;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.network.Network;
import com.jme3.network.Server;
import com.jme3.network.serializing.Serializer;
import com.jme3.network.service.serializer.ServerSerializerRegistrationsService;
import java.io.IOException;
import java.net.InetAddress;

public class MainServer extends SimpleApplication implements ConnectionListener, MessageListener<HostedConnection> {

    private Server myServer;
    private final int port = 1234; // change here and in the MainClient for another port of choice

    @Override
    public void simpleInitApp() {

        // initialize the server thread
        try {
            myServer = Network.createServer(port);
            myServer.getServices().removeService(myServer.getServices().getService(ServerSerializerRegistrationsService.class));
            Serializer.registerClass(PositionRotationMessage.class);
            Serializer.registerClass(ClientData.class);
            Serializer.registerClass(ClientListMessage.class);
            Serializer.registerClass(CloseMessage.class);
            myServer.addMessageListener(this);
            myServer.addConnectionListener(this);
            myServer.start();
            System.out.println("Server address: " + InetAddress.getLocalHost().getHostAddress());
        } catch (IOException ex) {
            System.out.println("Error starting the server");
        }

        // Create a Thread that sends all client-data to the clients that are connected
        ThreadSendClientList tscl = new ThreadSendClientList();
        tscl.setServer(myServer);
        Thread threadSend = new Thread(tscl);
        threadSend.start();
    }

    @Override
    public void simpleUpdate(float tpf) {

    }

    @Override
    public void destroy() {
        for (HostedConnection h : myServer.getConnections()) {
            h.close("");
        }
        myServer.close();
        super.destroy();
    }

    /**
     * If a new client is connected its attributes position and rotation are
     * initialized
     *
     * @param s the server
     * @param c a new connetced client
     */
    @Override
    public void connectionAdded(Server s, HostedConnection c) {
        c.setAttribute("pos", Vector3f.ZERO);
        c.setAttribute("rot", Quaternion.ZERO);
    }

    /**
     * Send a message to all clients that this given client has disconnected
     *
     * @param s the server
     * @param c the disconnected client
     */
    @Override
    public void connectionRemoved(Server s, HostedConnection c) {
        // inform the clients to remove this client from the players' HashMap
        CloseMessage cm = new CloseMessage(c.getId());
        cm.setReliable(true); // safe way
        myServer.broadcast(cm);
    }

    /**
     * if a client sends his position and rotation save the information on the
     * HostedConnection itself
     *
     * @param c the client that sends its data
     * @param pMessage the Message (position and rotation)
     */
    @Override
    public void messageReceived(HostedConnection c, Message pMessage) {

        if (pMessage instanceof PositionRotationMessage) {
            PositionRotationMessage cm = (PositionRotationMessage) pMessage;
            c.setAttribute("pos", cm.getPosVector());
            c.setAttribute("rot", cm.getRotQuaternion());
        }
    }
}
