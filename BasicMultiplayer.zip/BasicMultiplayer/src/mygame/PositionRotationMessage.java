package mygame;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.network.AbstractMessage;
import com.jme3.network.serializing.Serializable;

/**
 * A PositionRotationMessage is used to send the position and rotation from a
 * client to the server. Therefore the cam's location and rotation is used.
 *
 * @author danieljanssen
 */
@Serializable
public class PositionRotationMessage extends AbstractMessage {

    private Vector3f posV;
    private Quaternion rotQ;

    public PositionRotationMessage() {
    }

    public PositionRotationMessage(Vector3f pPosV, Quaternion pRotQ) {
        this.posV = pPosV;
        this.rotQ = pRotQ;
    }

    public Vector3f getPosVector() {
        return posV;
    }

    public Quaternion getRotQuaternion() {
        return rotQ;
    }
}
