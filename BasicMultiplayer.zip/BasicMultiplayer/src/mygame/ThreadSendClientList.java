package mygame;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.network.HostedConnection;
import com.jme3.network.Server;
import java.util.HashMap;

/**
 * This Thread is executed by the server. About 20 times per second this Thread
 * sends the data (from all clients) from the server to every single client.
 * Therefore every client's attributes 'position' and 'rotaion' are stored
 * within the HostedConnection itself on the server, are then read out here and
 * mapped as a ClientData packet to a HashMap with ID and ClientData. This
 * Hashmap is then sent to all clients via this Thread using a
 * ClientListMessage.
 *
 * @author danieljanssen
 */
public class ThreadSendClientList implements Runnable {

    // a reference to the server 
    private Server refServer;

    public void setServer(Server pServer) {
        refServer = pServer;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // build a new up-to-date HashMap of all players (with ID and ClientData)
                HashMap<Integer, ClientData> clientList = new HashMap<>();
                for (HostedConnection c : refServer.getConnections()) {
                    ClientData tmp = new ClientData((Vector3f) c.getAttribute("pos"), (Quaternion) c.getAttribute("rot"));
                    clientList.put(c.getId(), tmp);
                }
                // send the clientlist to the clients
                ClientListMessage clm = new ClientListMessage(clientList);
                clm.setReliable(false);
                refServer.broadcast(clm);

                Thread.sleep(50);
            }
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
